---
permalink: /calendar/
title: "Calendar"
excerpt: "Trips and Socials Calendar"
last_modified_at: 2022-02-13
toc: false
---

## Trips and Socials for 2022

Details about specific events will be distributed on the club mailing list close to each event. Please keep an eye out!

Click to add the [Club Trips Calendar](https://user.fm/calendar/v1-97ffe7f2dae5bc7a1e40633edbb11cee/Calendar.ics).

| Dates           | Location                                        |
|-----------------|-------------------------------------------------|
| February 25–27  | Peaks East - Stanage                            |
| March 25–27     | Wye Valley - Wintours or Shorn Cliff            |
| April 15–18     | Peaks West - Roaches (Bank Holiday)             |
| Apr 29–2        | North Wales - Llanberis (Bank Holiday)          |
| May 27–29       | Clwyd Limestone - Llanymynech Quarry            |
| June 24–26      | Lake District - Langdale                        |
| July 22–24      | Peaks East - Stanage                            |
| August 26–29    | North Pembroke - St Davids Head (Bank Holiday)  |
| September 23–25 | Peaks West - Roaches                            |
| October TBD     | Winter Sun Week Away - TBD                      |
| November 25–27  | North Wales Cheese & Port Trip - Llanberis      |

---

Warwick Climbing Club is a BMC affiliated club run by and for it's members.
