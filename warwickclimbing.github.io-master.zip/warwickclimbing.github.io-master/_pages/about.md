---
permalink: /about/
title: "About WCC"
excerpt: "About Warwick Climbing Club"
last_modified_at: 2020-05-09
toc: true
---

## A Brief History
In the beginning there was Leamington Mountaineering Club which was certainly in existence in the early 1980's and met in the old Haunch of Venison in the Parade. The club currently have three or four members who belonged to the Leamington club, however, age and alcohol have dulled their memories so if anyone has more details it would be greatly appreciated. :smile:

In the mid 1980's Leamington Mountaineering Club gained an offshoot ,the Newbold Comyn Arms Outdoor Pursuit Club. This undertook regular trips normally culminating in a New Years vist to Brotherswater in the Lake District.

Warwick Climbing Club was formed in 1992/3 from the bones of Leamington Mountaineering Club by Alan Jeffs and Barry Woodbridge. Barry and Pauline Woodbridge served as secretary and treasurer respectively, until 2000. It was during this period that the wall at St Nicholas Park was built, funded by the club, Warwick's Henry VIII Charity and Warwick District Council.

---

Warwick Climbing Club is a BMC affiliated club run by and for it's members.
