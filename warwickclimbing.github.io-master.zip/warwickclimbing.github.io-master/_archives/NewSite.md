---
title:  "New WCC website for 2020!"
excerpt: "The committee decided to investigate improving the club website."
categories:
  - Post
tags:
  - news
---

For 2020 the committee decided it would be a good idea to investigate improving the club website, with the aim of reducing some costs and simplifying it to enable any committee member to contribute updates to it. You're now looking at the result of this work!

The clubs former website had been designed and maintained over many years thanks entirely to the efforts and free time of longstanding club and committee member Dave Button. We (the committee) would like to take this opportunity to thank Dave for all the work he has done previously and for continuing to assist with the project of moving over to the new site.

Expect to see more updates here soon!
